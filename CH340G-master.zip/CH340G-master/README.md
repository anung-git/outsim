# CH340G
CH340G library for cadsoft eagle

This is a modified version of Ian's CH340G library. You can find [more information on his blog](http://fobit.blogspot.com/2014/11/ch340g-in-eagle.html)

